'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {".git/COMMIT_EDITMSG": "bc0e166808e73875eefe1319e66a2a37",
".git/config": "fc7e82fde5422b479957672f79f3db86",
".git/description": "a0a7c3fff21f2aea3cfa1d0316dd816c",
".git/FETCH_HEAD": "7cb417358e5c53ba664c1aecd0af2a8f",
".git/HEAD": "cf7dd3ce51958c5f13fece957cc417fb",
".git/hooks/applypatch-msg.sample": "ce562e08d8098926a3862fc6e7905199",
".git/hooks/commit-msg.sample": "579a3c1e12a1e74a98169175fb913012",
".git/hooks/fsmonitor-watchman.sample": "a0b2633a2c8e97501610bd3f73da66fc",
".git/hooks/post-update.sample": "2b7ea5cee3c49ff53d41e00785eb974c",
".git/hooks/pre-applypatch.sample": "054f9ffb8bfe04a599751cc757226dda",
".git/hooks/pre-commit.sample": "5029bfab85b1c39281aa9697379ea444",
".git/hooks/pre-merge-commit.sample": "39cb268e2a85d436b9eb6f47614c3cbc",
".git/hooks/pre-push.sample": "2c642152299a94e05ea26eae11993b13",
".git/hooks/pre-rebase.sample": "56e45f2bcbc8226d2b4200f7c46371bf",
".git/hooks/pre-receive.sample": "2ad18ec82c20af7b5926ed9cea6aeedd",
".git/hooks/prepare-commit-msg.sample": "2b5c047bdb474555e1787db32b2d2fc5",
".git/hooks/push-to-checkout.sample": "c7ab00c7784efeadad3ae9b228d4b4db",
".git/hooks/sendemail-validate.sample": "4d67df3a8d5c98cb8565c07e42be0b04",
".git/hooks/update.sample": "647ae13c682f7827c22f5fc08a03674e",
".git/index": "d8ef9163c82834d959dbaea29613bbbe",
".git/info/exclude": "036208b4a1ab4a235d75c181e685e5a3",
".git/logs/HEAD": "930af9acc1e03f2306d450588ecfd17b",
".git/logs/refs/heads/main": "1916d56a4f37f4d37907cd577ab75c12",
".git/logs/refs/remotes/origin/HEAD": "2c2961184e4eaa71629462558fe83669",
".git/logs/refs/remotes/origin/main": "36256da60f147a534b91a9369c83f2c2",
".git/objects/03/2fe904174b32b7135766696dd37e9a95c1b4fd": "80ba3eb567ab1b2327a13096a62dd17e",
".git/objects/14/22862478178d62b0bd90e1d763613c19cd2f9d": "54d038f55b01012ef5b2e26aee584c29",
".git/objects/1a/630bae2eaedf473c0f23ee5540ff57f848167e": "5d8dd311909da6b9f6fdd5d3a554ceff",
".git/objects/1a/b776d7deafa48692e0835bd9d028bd26fb4f08": "e104b50e816d1b277b000af8f2f910ed",
".git/objects/1c/370586a27ba5bed0e38db42c46a57c4551449e": "d5972a183e006abc537d125c6bf27192",
".git/objects/1d/a0d9f37e0e45551dc7397c86223fd8e14271e9": "a291681b23c51b8d15aaf7089e9df9fe",
".git/objects/1e/d733a449828dad6a03cb02669ddbc55daa7009": "714d9c8132900e2de26e96305732dfae",
".git/objects/24/8f58ee3d56db0f9c77afc1fe7e4554dc9eb1af": "12c2a32fa24ab4e805957db46e645324",
".git/objects/25/f634682fa7057ea0ef91bad42723345b974c42": "e08fecf8abeb014597c5dd978308a830",
".git/objects/25/fe3c6b6677ff9e7ad39fe8e6de536e593d6b41": "097b43feeff21f07e7990082a31e7d71",
".git/objects/27/830ffc9d6e5144dd1984a0d86aca3f5eb679d6": "39102297ee8eec8839cbe56bd79915ac",
".git/objects/28/776e6815e293008464928ef7c262c1cb57a6e1": "ccbbf9e64384bbf795dd7311b5030893",
".git/objects/2c/df19215eac0a025668d6076100e3602eda9492": "8f7d1b5599816c92314026555eda0676",
".git/objects/33/31d9290f04df89cea3fb794306a371fcca1cd9": "e54527b2478950463abbc6b22442144e",
".git/objects/33/bc9f95cc50bc50af29f8c0c2332532698c3c0d": "a119f2908292ac18450073f4448e3430",
".git/objects/35/96d08a5b8c249a9ff1eb36682aee2a23e61bac": "e931dda039902c600d4ba7d954ff090f",
".git/objects/35/b78bfd82412e9fb252b2b1518dfa6bff0be037": "5b2cd62fa82eeee14abfd49b91988025",
".git/objects/36/497a3b1f82ccc4b996c57e1e7c590b7818a32b": "b61e1f9b9e35259fb9f440b13456ae91",
".git/objects/39/1a711b9487c4874d53904e284cd89d15b0fca9": "0eb9c7be0cb7987efabd46a174d8d77b",
".git/objects/3a/68f413c70ca216779f9588d0ca87e3ec5f7071": "a6a2647c7a22cab71be6ec8c00affd54",
".git/objects/3b/95b4e5eb88a09d31e74094f945924f15f242d4": "c4c5f9c5e0348a8e1a86a181b26c1dbd",
".git/objects/3f/c2ecbd5c3ebfd9d1503c0e59ba2e3c9a71682d": "3a052cae0136664815c86f463a38ed42",
".git/objects/40/1184f2840fcfb39ffde5f2f82fe5957c37d6fa": "1ea653b99fd29cd15fcc068857a1dbb2",
".git/objects/40/4e378982df598b8f76185bef0ee95a0edefb0f": "cb7598236bdb0848e92da068552e9c93",
".git/objects/43/5b15a84f6aa43a9bc88e9844543898b46a2bea": "2fa318e555d5bfbe8a68189785288ee5",
".git/objects/46/4ab5882a2234c39b1a4dbad5feba0954478155": "2e52a767dc04391de7b4d0beb32e7fc4",
".git/objects/4f/02e9875cb698379e68a23ba5d25625e0e2e4bc": "254bc336602c9480c293f5f1c64bb4c7",
".git/objects/53/97982e712a3111ac3c213bbce47eadb2cfb146": "477a461109fddb44a4d3a061ca31571c",
".git/objects/55/57ae0651a5e8b155c045b58aad6323eef99094": "bc3f03ea9a3dd725ebfe0afd701d2cb2",
".git/objects/55/e3d2546ccb4b66a34619498b02a64960760bc7": "6433b21b9fd76602983ae3018b1d5e2e",
".git/objects/56/2ec74b2f372daa0110306af5590ac060f7bcdb": "db8e0510e000f465fb1f5f2a4df70bef",
".git/objects/57/7946daf6467a3f0a883583abfb8f1e57c86b54": "846aff8094feabe0db132052fd10f62a",
".git/objects/58/157cd6b4e3c5e2506f188c966f4e4e47ff332a": "2255f8ac38fd6d2f2962022339e4826b",
".git/objects/58/31ea0cbc3b69fedd80363335cb1edaeb4ec0bc": "85ef2ec11b27a661abeca8a344642c12",
".git/objects/59/4346d80532b28a34c674e77c9df754d55da3f5": "10456af4e9c15989953dfc45ea2096a3",
".git/objects/5a/b06242f4f0b3e607c799a38d13d934944fe769": "d20aaafa680ac3ceec480a01f30e7740",
".git/objects/5f/bf1f5ee49ba64ffa8e24e19c0231e22add1631": "f19d414bb2afb15ab9eb762fd11311d6",
".git/objects/61/ccee8f111250905ac88b53240afb11f12a9339": "673b82e191f5a51c1c9ba93192b4f98f",
".git/objects/64/5116c20530a7bd227658a3c51e004a3f0aefab": "f10b5403684ce7848d8165b3d1d5bbbe",
".git/objects/67/bbdeea74699d40fd86a1438123d64f9f2dd248": "d1e10db735dd455eb39c7c71b2671480",
".git/objects/6a/63925e4f85fac0523e762a46b0bcc614774f31": "dc5ce90bffbf63948aba01ff0cbbeae9",
".git/objects/6b/9862a1351012dc0f337c9ee5067ed3dbfbb439": "85896cd5fba127825eb58df13dfac82b",
".git/objects/6c/54faf143effef2036f5d8c820134b227f9c8c3": "1287f63a8e147dbc145044b7011ef7a0",
".git/objects/6f/9478959907c7916972b9925eff82455e81de06": "df130e505c766d9446ad71e5ee9d0434",
".git/objects/71/8de521f8abad2bb1d25e912f91169602ac4dfd": "9abbf6cf9a1223aca5a5b5fc96f42f7b",
".git/objects/73/8ea903baf5765c7e0ec96a009338eb01fa163a": "f42bfd5c5c014a7353f24ceb0db9a0ff",
".git/objects/73/e36afdaa59567d5a01a4cdf619eb32c2331a49": "2942df96a90297dbf40e5c915ee2fe7a",
".git/objects/74/794b397a4a46710bfcacd18f8d807ef0baec23": "2c94e2d78ab2822a7a6874dfca2a0f5a",
".git/objects/76/5e070857dcee1452effdab588f404962ee6147": "460038a81d00a0038b195c5e3876b849",
".git/objects/76/b6e6d1b1e338dc15078c8f469ef5d8b9cd75a7": "f8a133bddc3d1914f6ab37955a7cf6f0",
".git/objects/79/0250989e5b4de7bdb211d7f88137de09eb2b00": "524f7761aa0d2520966ce64a0b66d6e5",
".git/objects/7d/662fe8135fde632d6c97e6b02d8981038d658d": "bc16c43328d20a4ecebb9f2b7ce410d0",
".git/objects/82/9dc9100642180e11ce14616fed105138e48f7e": "30f04ba03e191c62e2445998b0d13415",
".git/objects/83/1cff52e8000d8aaad9c275a657657fd05cb1c4": "063831acba00b7e6abc72f6db5b1abab",
".git/objects/88/cfd48dff1169879ba46840804b412fe02fefd6": "e42aaae6a4cbfbc9f6326f1fa9e3380c",
".git/objects/8a/51a9b155d31c44b148d7e287fc2872e0cafd42": "9f785032380d7569e69b3d17172f64e8",
".git/objects/8a/aa46ac1ae21512746f852a42ba87e4165dfdd1": "1d8820d345e38b30de033aa4b5a23e7b",
".git/objects/91/4a40ccb508c126fa995820d01ea15c69bb95f7": "8963a99a625c47f6cd41ba314ebd2488",
".git/objects/91/bca39c824ec9b43ca1f9a0a455440d5a5fa86f": "d7cdf52342e7d2b74be981769e726179",
".git/objects/93/6df20b76c485edc445425cb984dadda0ccf11c": "af1d0d5d235557a749227a6c35a44beb",
".git/objects/93/be7fd9b9dcdd8564dafd7040a0c8c8f68d4080": "b27ff257c793a735fc818ff37f392ff9",
".git/objects/94/1cf341fedbb92107c559b3595bd89e162046eb": "62dce25555988adb91272e2a4d1edae9",
".git/objects/9a/1042c9a3dce1a7b7f3f8aa43301ac72b1fb388": "af5a344b75cb5f0d4662225adcfb4156",
".git/objects/9c/77e0d481137e96ff6241cfcbf0b567d036ef86": "bb41273930a5ed2aa8a53cc66afab4a9",
".git/objects/a0/bd9bf0f7a671538ad627db0813f5a4ff61cda6": "766dd09ede3539d656227ca7195dc597",
".git/objects/a2/14bff01614c277c5145c3deef727869b3b5bb3": "1b8be4ec403d13a4b154c27e36df2606",
".git/objects/a5/de584f4d25ef8aace1c5a0c190c3b31639895b": "9fbbb0db1824af504c56e5d959e1cdff",
".git/objects/a8/8c9340e408fca6e68e2d6cd8363dccc2bd8642": "11e9d76ebfeb0c92c8dff256819c0796",
".git/objects/a9/891b4324c6ab69ac0723492231b8d07f66841c": "4d598f22c929cc0250ac968b0945e83b",
".git/objects/aa/fdc465199015367dc577abaf809c886f0d2413": "1630eb12049ead0a899674c2d3a24dab",
".git/objects/ad/1ec2d6b09a07a5386bf6135f71f8b8e3da4a33": "919f4ee68c4eabc8e901fed304e832b7",
".git/objects/b7/434ea958b40e7ba6c92e5559ceb426f39816d7": "3464aac78a26bb59a82510ee78f8807f",
".git/objects/b7/49bfef07473333cf1dd31e9eed89862a5d52aa": "36b4020dca303986cad10924774fb5dc",
".git/objects/b9/2a0d854da9a8f73216c4a0ef07a0f0a44e4373": "f62d1eb7f51165e2a6d2ef1921f976f3",
".git/objects/bb/4c36a44e3bbbd129c8a1d392ce216ac4a6c0ce": "34cb6a6b3bc71a7fc4d922231fc96dc1",
".git/objects/bc/8b08466976baa9d259ee29ba17ac60b21d7b7b": "e497b2523191113a2be65814e3fd88aa",
".git/objects/bf/443d2d674cbd32bef338390efad815abaadf62": "5207511dbebb90d3e3d00a16d787f452",
".git/objects/c1/4f9ac150c8d5f866c661f8165bd0fc0f5c6fdf": "248e251aad9f667fdad5996d07655fe8",
".git/objects/c1/8aff88a206dd8f8e61387e20e2d94deafb5058": "b691785276fc170d15c24aa367f77813",
".git/objects/c2/d26b7098d064e92b36927930d150400e2988fa": "999d0e99a9028e76ccee7cc802ca2615",
".git/objects/c5/d18e09103ee3fa8af84c8a5a8c2e8471d613bc": "0005f0851b70363f8a14bbd3a4202900",
".git/objects/c7/1de71b79e8c5206a5c98a9b7bd7e1ce60a9e5a": "0fc68dbad35f7848ea555b659841388f",
".git/objects/c7/735e526a7e82c82e5c00c619f7d304cde9e1b2": "b57932e0aebc296b84cce00a220ac62f",
".git/objects/c8/367c00809380cd5e4954e2df6a384256198012": "af5c35d1354149469ffb222d23901792",
".git/objects/c9/15da0c165609b426c49257afa4befa029124ab": "ef567fd3586e0b058d27ddb349e87ec5",
".git/objects/c9/d7d45ba0c52e8fa09f2c42d9819eb88682a686": "3d42fac3d05981150ff28c5ea6cafb06",
".git/objects/ca/645d80a8dd10c97ef07edeca79f3f14ef5f9ab": "7e7f39db5f6520f86f133f5238871924",
".git/objects/d4/3532a2348cc9c26053ddb5802f0e5d4b8abc05": "3dad9b209346b1723bb2cc68e7e42a44",
".git/objects/d4/9675e61b9a37082602902a22fc9320286b85c2": "48c8972ac738a5efc0d3667e5582a26c",
".git/objects/d5/9511c97f5b900f3a674fee59de85926928ae32": "bf1019e80b274d5af8e0277df200a093",
".git/objects/d6/55cb651147f7ef9b7f251e4e8f7a217f3235e2": "92516ce504c1a8391c650e7ee37113fd",
".git/objects/d6/6b90c605b47d478306a971ff8f6ddd145f5df7": "21da2efe6deb66a218acf0252270d0f0",
".git/objects/d6/9c56691fbdb0b7efa65097c7cc1edac12a6d3e": "868ce37a3a78b0606713733248a2f579",
".git/objects/d7/7cfefdbe249b8bf90ce8244ed8fc1732fe8f73": "9c0876641083076714600718b0dab097",
".git/objects/d9/3952e90f26e65356f31c60fc394efb26313167": "1401847c6f090e48e83740a00be1c303",
".git/objects/d9/abbc2506c5432eadd4d40595275b4bf8d9adff": "c325d7806a17de4a740e755edb7f36bf",
".git/objects/d9/d16fd219be9d8c37b0a3358bd5df233bdb06e7": "dc4d224a576e15c8cbbf27c91eb515ef",
".git/objects/d9/fabe01920bb73bafcef98025cb6ee2a21e6775": "669cfbe5b822fe47722c4b632c05e6bc",
".git/objects/de/6366ff181750a034ad5f33cf40afb89b044b55": "bb221a795484740980d4cf74befde567",
".git/objects/df/73706774e493c5fea209d043ec7c78e4b8c13d": "93e05419e4ebb4bba355725855373a85",
".git/objects/e2/644109c2664bea80827a86b004873a00bd1717": "cf0d5043f9d8019bc987d56acd683a06",
".git/objects/e5/4dda75887bf26cda2d97cce4c448b830c736c1": "c1420513700d8e8485b50411d6c1bd0d",
".git/objects/e9/94225c71c957162e2dcc06abe8295e482f93a2": "2eed33506ed70a5848a0b06f5b754f2c",
".git/objects/e9/f39e5c070cd026fb7a7e704e0c63e63bf4e820": "35141651d48c312d9c6e051f96ce56a1",
".git/objects/ea/644298b14798dcd61f6382c82e37df240d49c6": "deae0cc79bc78c090817ff6b071c7128",
".git/objects/eb/9b4d76e525556d5d89141648c724331630325d": "37c0954235cbe27c4d93e74fe9a578ef",
".git/objects/ec/31169a253be3c4e2b1d1c21626709fbef09861": "f494e82a318a98e281d034e97e8f7e9d",
".git/objects/ec/5cb7c03dfed9081b82f0e8966c0d21329f5e55": "abd46ea8e7d727b041ca677ed58c8329",
".git/objects/ef/b875788e4094f6091d9caa43e35c77640aaf21": "27e32738aea45acd66b98d36fc9fc9e0",
".git/objects/f0/2f52cf459329d3812b662e5f91dbda6110e6e6": "755f4cea985d11705480cefcdb4cbeed",
".git/objects/f0/f4cc14059c17a3597d939d2c048e2219796958": "7aa4b4b6ba7f5f7513287d63a1c7e27f",
".git/objects/f2/04823a42f2d890f945f70d88b8e2d921c6ae26": "6b47f314ffc35cf6a1ced3208ecc857d",
".git/objects/f3/309a9eeff5703ac849cda40ba9827ed918d822": "5f351275bbac0dc4d5e474ea0bbc7c21",
".git/objects/f3/709a83aedf1f03d6e04459831b12355a9b9ef1": "538d2edfa707ca92ed0b867d6c3903d1",
".git/objects/f5/72b90ef57ee79b82dd846c6871359a7cb10404": "e68f5265f0bb82d792ff536dcb99d803",
".git/objects/f7/1ddd1129f677bd70dac0f83a678a01c701b740": "c576a799d57318d3abcafe0685d0c681",
".git/ORIG_HEAD": "9d03bb70dea32eeab01e18e241155687",
".git/refs/heads/main": "1b2a2b67d9cf401c874a0b05ce2ba5cb",
".git/refs/remotes/origin/HEAD": "98b16e0b650190870f1b40bc8f4aec4e",
".git/refs/remotes/origin/main": "1b2a2b67d9cf401c874a0b05ce2ba5cb",
"assets/AssetManifest.bin": "e22653ede92eaa0b547b48b0c8b2bc0c",
"assets/AssetManifest.bin.json": "99a97df8255cc1642883bc1b4df3e618",
"assets/AssetManifest.json": "e21f0de3e9ae975381dc3c047df17ba2",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/fonts/MaterialIcons-Regular.otf": "e03de78f2d60e99f1f94ef6be41095d1",
"assets/NOTICES": "09d2ceb9072fdf1766f45762e617b495",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"canvaskit/canvaskit.js": "86e461cf471c1640fd2b461ece4589df",
"canvaskit/canvaskit.js.symbols": "68eb703b9a609baef8ee0e413b442f33",
"canvaskit/canvaskit.wasm": "efeeba7dcc952dae57870d4df3111fad",
"canvaskit/chromium/canvaskit.js": "34beda9f39eb7d992d46125ca868dc61",
"canvaskit/chromium/canvaskit.js.symbols": "5a23598a2a8efd18ec3b60de5d28af8f",
"canvaskit/chromium/canvaskit.wasm": "64a386c87532ae52ae041d18a32a3635",
"canvaskit/skwasm.js": "f2ad9363618c5f62e813740099a80e63",
"canvaskit/skwasm.js.symbols": "80806576fa1056b43dd6d0b445b4b6f7",
"canvaskit/skwasm.wasm": "f0dfd99007f989368db17c9abeed5a49",
"canvaskit/skwasm_st.js": "d1326ceef381ad382ab492ba5d96f04d",
"canvaskit/skwasm_st.js.symbols": "c7e7aac7cd8b612defd62b43e3050bdd",
"canvaskit/skwasm_st.wasm": "56c3973560dfcbf28ce47cebe40f3206",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"flutter.js": "76f08d47ff9f5715220992f993002504",
"flutter_bootstrap.js": "94133396b3a4f68de4b30b00871d5b27",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "1177f2e5c23fbaf89f7dc8012ddc4129",
"/": "1177f2e5c23fbaf89f7dc8012ddc4129",
"main.dart.js": "3981d6b59a7164db335ae8b531cf6d1e",
"manifest.json": "0932a116b563f9e9c2a852283547da56",
"README.md": "18ef079ef228115680668e413e46c486",
"version.json": "90a18c3203fa900e9e92d3e42fdac35e"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
